import { db } from "./db";
import { 
  users, assets, liabilities, transactions,
  type User, type InsertUser,
  type Asset, type InsertAsset, type UpdateAssetRequest,
  type Liability, type InsertLiability, type UpdateLiabilityRequest,
  type Transaction, type InsertTransaction, type CreateTransactionRequest
} from "@shared/schema";
import { eq, desc, sql } from "drizzle-orm";

export interface IStorage {
  // User
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUserCurrency(id: number, currency: string): Promise<void>;

  // Assets
  getAssets(userId: number): Promise<Asset[]>;
  getAsset(id: number): Promise<Asset | undefined>;
  createAsset(asset: InsertAsset): Promise<Asset>;
  updateAsset(id: number, updates: UpdateAssetRequest): Promise<Asset>;
  deleteAsset(id: number): Promise<void>;

  // Liabilities
  getLiabilities(userId: number): Promise<Liability[]>;
  getLiability(id: number): Promise<Liability | undefined>;
  createLiability(liability: InsertLiability): Promise<Liability>;
  updateLiability(id: number, updates: UpdateLiabilityRequest): Promise<Liability>;
  deleteLiability(id: number): Promise<void>;

  // Transactions
  getTransactions(userId: number): Promise<Transaction[]>;
  createTransaction(transaction: InsertTransaction): Promise<Transaction>;
  deleteTransaction(id: number): Promise<void>;
  
  // Dashboard Aggregates (could be optimized with raw SQL later)
}

export class DatabaseStorage implements IStorage {
  // User
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db.insert(users).values(insertUser).returning();
    return user;
  }

  async updateUserCurrency(id: number, currency: string): Promise<void> {
    await db.update(users).set({ preferredCurrency: currency }).where(eq(users.id, id));
  }

  // Assets
  async getAssets(userId: number): Promise<Asset[]> {
    return await db.select().from(assets).where(eq(assets.userId, userId));
  }

  async getAsset(id: number): Promise<Asset | undefined> {
    const [asset] = await db.select().from(assets).where(eq(assets.id, id));
    return asset;
  }

  async createAsset(insertAsset: InsertAsset): Promise<Asset> {
    const [asset] = await db.insert(assets).values(insertAsset).returning();
    return asset;
  }

  async updateAsset(id: number, updates: UpdateAssetRequest): Promise<Asset> {
    const [updated] = await db.update(assets).set(updates).where(eq(assets.id, id)).returning();
    return updated;
  }

  async deleteAsset(id: number): Promise<void> {
    await db.delete(assets).where(eq(assets.id, id));
  }

  // Liabilities
  async getLiabilities(userId: number): Promise<Liability[]> {
    return await db.select().from(liabilities).where(eq(liabilities.userId, userId));
  }

  async getLiability(id: number): Promise<Liability | undefined> {
    const [liability] = await db.select().from(liabilities).where(eq(liabilities.id, id));
    return liability;
  }

  async createLiability(insertLiability: InsertLiability): Promise<Liability> {
    const [liability] = await db.insert(liabilities).values(insertLiability).returning();
    return liability;
  }

  async updateLiability(id: number, updates: UpdateLiabilityRequest): Promise<Liability> {
    const [updated] = await db.update(liabilities).set(updates).where(eq(liabilities.id, id)).returning();
    return updated;
  }

  async deleteLiability(id: number): Promise<void> {
    await db.delete(liabilities).where(eq(liabilities.id, id));
  }

  // Transactions
  async getTransactions(userId: number): Promise<Transaction[]> {
    return await db.select().from(transactions)
      .where(eq(transactions.userId, userId))
      .orderBy(desc(transactions.date));
  }

  async createTransaction(insertTransaction: InsertTransaction): Promise<Transaction> {
    const [transaction] = await db.insert(transactions).values(insertTransaction).returning();
    return transaction;
  }

  async deleteTransaction(id: number): Promise<void> {
    await db.delete(transactions).where(eq(transactions.id, id));
  }
}

export const storage = new DatabaseStorage();
