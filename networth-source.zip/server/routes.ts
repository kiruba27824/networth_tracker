import type { Express } from "express";
import type { Server } from "http";
import { setupAuth } from "./auth";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { z } from "zod";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  // Setup Auth (Passport + Session)
  setupAuth(app);

  // Middleware to check authentication
  const requireAuth = (req: any, res: any, next: any) => {
    if (req.isAuthenticated()) {
      return next();
    }
    res.status(401).json({ message: "Unauthorized" });
  };

  // === Assets ===
  app.get(api.assets.list.path, requireAuth, async (req, res) => {
    const assets = await storage.getAssets(req.user!.id);
    res.json(assets);
  });

  app.post(api.assets.create.path, requireAuth, async (req, res) => {
    try {
      const input = api.assets.create.input.parse(req.body);
      const asset = await storage.createAsset({ ...input, userId: req.user!.id });
      res.status(201).json(asset);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({ message: err.errors[0].message });
      }
      throw err;
    }
  });

  app.put(api.assets.update.path, requireAuth, async (req, res) => {
    try {
      const input = api.assets.update.input.parse(req.body);
      const asset = await storage.updateAsset(Number(req.params.id), input);
      res.json(asset);
    } catch (err) {
       if (err instanceof z.ZodError) {
        return res.status(400).json({ message: err.errors[0].message });
      }
      res.status(404).json({ message: "Asset not found" });
    }
  });

  app.delete(api.assets.delete.path, requireAuth, async (req, res) => {
    await storage.deleteAsset(Number(req.params.id));
    res.status(204).send();
  });

  // === Liabilities ===
  app.get(api.liabilities.list.path, requireAuth, async (req, res) => {
    const liabilities = await storage.getLiabilities(req.user!.id);
    res.json(liabilities);
  });

  app.post(api.liabilities.create.path, requireAuth, async (req, res) => {
    try {
      const input = api.liabilities.create.input.parse(req.body);
      const liability = await storage.createLiability({ ...input, userId: req.user!.id });
      res.status(201).json(liability);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({ message: err.errors[0].message });
      }
      throw err;
    }
  });

  app.put(api.liabilities.update.path, requireAuth, async (req, res) => {
    try {
      const input = api.liabilities.update.input.parse(req.body);
      const liability = await storage.updateLiability(Number(req.params.id), input);
      res.json(liability);
    } catch (err) {
       if (err instanceof z.ZodError) {
        return res.status(400).json({ message: err.errors[0].message });
      }
      res.status(404).json({ message: "Liability not found" });
    }
  });

  app.delete(api.liabilities.delete.path, requireAuth, async (req, res) => {
    await storage.deleteLiability(Number(req.params.id));
    res.status(204).send();
  });

  // === Transactions ===
  app.get(api.transactions.list.path, requireAuth, async (req, res) => {
    const transactions = await storage.getTransactions(req.user!.id);
    res.json(transactions);
  });

  app.post(api.transactions.create.path, requireAuth, async (req, res) => {
    try {
      const input = api.transactions.create.input.parse(req.body);
      // Ensure date is properly parsed if it's a string, though Zod schema handles it mostly.
      // If schema says date is Date object, Zod might expect string if coming from JSON. 
      // InsertTransaction has date as Date | null.
      const transaction = await storage.createTransaction({ 
        ...input, 
        userId: req.user!.id,
        date: input.date ? new Date(input.date) : new Date() 
      });
      res.status(201).json(transaction);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({ message: err.errors[0].message });
      }
      throw err;
    }
  });

  app.delete(api.transactions.delete.path, requireAuth, async (req, res) => {
    await storage.deleteTransaction(Number(req.params.id));
    res.status(204).send();
  });

  // === User ===
  app.patch("/api/user/currency", requireAuth, async (req, res) => {
    const { currency } = req.body;
    if (!['INR', 'AED', 'USD'].includes(currency)) {
      return res.status(400).json({ message: "Invalid currency" });
    }
    await storage.updateUserCurrency(req.user!.id, currency);
    res.json({ ok: true });
  });

  // === Dashboard ===
  app.get(api.dashboard.get.path, requireAuth, async (req, res) => {
    const userId = req.user!.id;
    const user = await storage.getUser(userId);
    const assetsList = await storage.getAssets(userId);
    const liabilitiesList = await storage.getLiabilities(userId);
    const transactionsList = await storage.getTransactions(userId);

    const totalAssets = assetsList.reduce((sum, item) => sum + Number(item.value), 0);
    const totalLiabilities = liabilitiesList.reduce((sum, item) => sum + Number(item.outstandingAmount), 0);
    const netWorth = totalAssets - totalLiabilities;

    // Monthly income/expenses (current month)
    const now = new Date();
    const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);
    const monthlyTransactions = transactionsList.filter(t => t.date && new Date(t.date) >= startOfMonth);
    const monthlyIncome = monthlyTransactions
      .filter(t => t.type === 'INCOME')
      .reduce((sum, t) => sum + Number(t.amount), 0);
    const monthlyExpenses = monthlyTransactions
      .filter(t => t.type === 'EXPENSE')
      .reduce((sum, t) => sum + Number(t.amount), 0);

    // Gold Metrics
    const goldAssets = assetsList.filter(a => a.type === 'GOLD');
    let goldMetrics;
    if (goldAssets.length > 0) {
      const totalWeight = goldAssets.reduce((sum, item) => sum + (Number(item.weight) || 0), 0);
      const currentValue = goldAssets.reduce((sum, item) => sum + Number(item.value), 0);
      const investmentValue = goldAssets.reduce((sum, item) => {
        if (item.purchaseRate && item.weight) {
          return sum + (Number(item.purchaseRate) * Number(item.weight));
        }
        return sum + Number(item.value);
      }, 0);
      const plAmount = currentValue - investmentValue;
      const plPercent = investmentValue > 0 ? (plAmount / investmentValue) * 100 : 0;
      
      goldMetrics = {
        totalWeight,
        currentValue,
        investmentValue,
        plAmount,
        plPercent,
      };
    }

    res.json({
      totalAssets,
      totalLiabilities,
      netWorth,
      currency: user?.preferredCurrency || "INR",
      monthlyIncome,
      monthlyExpenses,
      goldMetrics
    });
  });

  return httpServer;
}
