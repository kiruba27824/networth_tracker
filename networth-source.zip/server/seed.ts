import { storage } from "./storage";
import { scrypt, randomBytes } from "crypto";
import { promisify } from "util";

const scryptAsync = promisify(scrypt);

async function hashPassword(password: string) {
  const salt = randomBytes(16).toString("hex");
  const buf = (await scryptAsync(password, salt, 64)) as Buffer;
  return `${buf.toString("hex")}.${salt}`;
}

async function runSeed() {
  console.log("Seeding database...");
  
  // Check if demo user exists
  const existing = await storage.getUserByUsername("demo");
  if (!existing) {
    const password = await hashPassword("demo123");
    const user = await storage.createUser({
      username: "demo",
      password,
      name: "Demo User",
      preferredCurrency: "INR",
      exchangeRate: "1.0",
    });
    console.log("Created demo user");

    // Assets
    await storage.createAsset({
      userId: user.id,
      type: "BANK",
      name: "HDFC Savings",
      value: "50000",
      currency: "INR"
    });
    
    await storage.createAsset({
      userId: user.id,
      type: "GOLD",
      name: "Gold Chain",
      value: "200000",
      currency: "INR",
      weight: "30", // grams
      purchaseRate: "5000" // per gram
    });

    // Liabilities
    await storage.createLiability({
      userId: user.id,
      type: "CREDIT_CARD",
      name: "ICICI Coral Credit Card",
      outstandingAmount: "15000",
      currency: "INR",
      totalLimit: "100000"
    });

    await storage.createLiability({
      userId: user.id,
      type: "LOAN",
      name: "Car Loan",
      outstandingAmount: "300000",
      currency: "INR",
      emi: "12000"
    });

    // Transactions
    await storage.createTransaction({
      userId: user.id,
      type: "INCOME",
      category: "Salary",
      amount: "100000",
      description: "January Salary",
      date: new Date() // Pass Date object
    });

    await storage.createTransaction({
      userId: user.id,
      type: "EXPENSE",
      category: "Groceries",
      amount: "5000",
      description: "Big Basket",
      date: new Date() // Pass Date object
    });
    
    console.log("Seed data created successfully");
  } else {
    console.log("Demo user already exists");
  }
}

runSeed().catch(console.error);
