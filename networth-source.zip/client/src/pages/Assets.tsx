import { useAssets, useDeleteAsset } from "@/hooks/use-assets";
import { CreateAssetDialog } from "@/components/CreateAssetDialog";
import { BottomNav } from "@/components/BottomNav";
import { PageHeader } from "@/components/PageHeader";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Trash2, TrendingUp, Building2, Wallet, CircleDollarSign } from "lucide-react";
import { formatDistanceToNow } from "date-fns";
import { motion, AnimatePresence } from "framer-motion";

export default function Assets() {
  const { data: assets, isLoading } = useAssets();
  const { mutate: deleteAsset } = useDeleteAsset();

  const getIcon = (type: string) => {
    switch (type) {
      case 'BANK': return <Building2 className="w-5 h-5 text-blue-400" />;
      case 'GOLD': return <TrendingUp className="w-5 h-5 text-yellow-400" />;
      case 'CASH': return <Wallet className="w-5 h-5 text-green-400" />;
      default: return <CircleDollarSign className="w-5 h-5 text-purple-400" />;
    }
  };

  return (
    <div className="min-h-screen bg-background pb-24 px-4 pt-8">
      <PageHeader 
        title="Assets" 
        subtitle="Track your wealth sources"
        action={<CreateAssetDialog />}
      />

      {isLoading ? (
        <div className="space-y-4">
          {[1,2,3].map(i => <div key={i} className="h-20 bg-secondary/30 rounded-2xl animate-pulse" />)}
        </div>
      ) : (
        <div className="space-y-4">
          <AnimatePresence>
            {assets?.map((asset) => (
              <motion.div
                key={asset.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.95 }}
                layout
              >
                <Card className="glass-card hover:bg-card/50 transition-colors group">
                  <div className="p-4 flex items-center justify-between">
                    <div className="flex items-center space-x-4">
                      <div className="w-10 h-10 rounded-full bg-background flex items-center justify-center border border-white/5">
                        {getIcon(asset.type)}
                      </div>
                      <div>
                        <h3 className="font-semibold text-foreground">{asset.name}</h3>
                        <p className="text-xs text-muted-foreground">{asset.type}</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="font-bold text-lg">
                        {new Intl.NumberFormat('en-IN', { style: 'currency', currency: asset.currency || 'INR', maximumFractionDigits: 0 }).format(Number(asset.value))}
                      </div>
                      <div className="flex justify-end gap-2 mt-1 opacity-0 group-hover:opacity-100 transition-opacity">
                         <Button 
                            variant="ghost" 
                            size="icon" 
                            className="h-6 w-6 text-destructive hover:text-destructive hover:bg-destructive/10"
                            onClick={() => {
                                if(confirm("Are you sure?")) deleteAsset(asset.id);
                            }}
                          >
                           <Trash2 className="w-3 h-3" />
                         </Button>
                      </div>
                    </div>
                  </div>
                </Card>
              </motion.div>
            ))}
          </AnimatePresence>
          
          {assets?.length === 0 && (
            <div className="text-center py-12 text-muted-foreground">
              <Wallet className="w-12 h-12 mx-auto mb-4 opacity-20" />
              <p>No assets yet. Add one to get started.</p>
            </div>
          )}
        </div>
      )}

      <BottomNav />
    </div>
  );
}
