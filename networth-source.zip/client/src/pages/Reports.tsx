import { useDashboard } from "@/hooks/use-dashboard";
import { useTransactions } from "@/hooks/use-transactions";
import { useAssets } from "@/hooks/use-assets";
import { BottomNav } from "@/components/BottomNav";
import { PageHeader } from "@/components/PageHeader";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  PieChart, Pie, Cell, ResponsiveContainer, Tooltip,
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Legend
} from 'recharts';
import { Loader2 } from "lucide-react";
import { format, startOfMonth, subMonths } from "date-fns";

const COLORS = ['#10b981', '#ef4444', '#6366f1', '#f59e0b', '#3b82f6', '#ec4899', '#14b8a6', '#f97316'];

export default function Reports() {
  const { data: dashboard, isLoading: dashLoading } = useDashboard();
  const { data: transactions, isLoading: txLoading } = useTransactions();
  const { data: assets, isLoading: assetsLoading } = useAssets();

  if (dashLoading || txLoading || assetsLoading) {
    return (
      <div className="flex h-screen items-center justify-center bg-background">
        <Loader2 className="w-10 h-10 animate-spin text-primary" />
      </div>
    );
  }

  const currency = dashboard?.currency || "INR";

  const fmt = (v: number) =>
    new Intl.NumberFormat('en-IN', { style: 'currency', currency, maximumFractionDigits: 0 }).format(v);

  // Net worth breakdown
  const netWorthData = [
    { name: 'Assets', value: dashboard?.totalAssets ?? 0 },
    { name: 'Liabilities', value: dashboard?.totalLiabilities ?? 0 },
  ].filter(d => d.value > 0);

  // Asset allocation by type
  const assetByType: Record<string, number> = {};
  (assets ?? []).forEach(a => {
    const type = a.type;
    assetByType[type] = (assetByType[type] || 0) + Number(a.value);
  });
  const assetAllocationData = Object.entries(assetByType).map(([name, value]) => ({ name, value }));

  // Income vs Expense — last 6 months
  const now = new Date();
  const last6Months = Array.from({ length: 6 }, (_, i) => {
    const d = subMonths(now, 5 - i);
    return { month: format(d, 'MMM'), start: startOfMonth(d), label: format(d, 'yyyy-MM') };
  });

  const incomeExpenseData = last6Months.map(({ month, start, label }) => {
    const end = new Date(start);
    end.setMonth(end.getMonth() + 1);
    const monthTxs = (transactions ?? []).filter(t => {
      if (!t.date) return false;
      const d = new Date(t.date);
      return d >= start && d < end;
    });
    return {
      month,
      Income: monthTxs.filter(t => t.type === 'INCOME').reduce((s, t) => s + Number(t.amount), 0),
      Expense: monthTxs.filter(t => t.type === 'EXPENSE').reduce((s, t) => s + Number(t.amount), 0),
    };
  });

  // Expense by category (all time)
  const expenseByCat: Record<string, number> = {};
  (transactions ?? []).filter(t => t.type === 'EXPENSE').forEach(t => {
    expenseByCat[t.category] = (expenseByCat[t.category] || 0) + Number(t.amount);
  });
  const expenseCatData = Object.entries(expenseByCat)
    .map(([name, value]) => ({ name, value }))
    .sort((a, b) => b.value - a.value)
    .slice(0, 8);

  const tooltipStyle = {
    backgroundColor: 'hsl(224 71% 7%)',
    borderColor: 'hsl(217 19% 27%)',
    color: 'hsl(210 40% 98%)',
    borderRadius: '8px',
    fontSize: '12px',
  };

  return (
    <div className="min-h-screen bg-background pb-24 px-4 pt-8">
      <PageHeader title="Reports" subtitle="Financial insights" />

      <div className="space-y-5">
        {/* Net Worth Breakdown */}
        <Card className="glass-card">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-semibold text-muted-foreground uppercase tracking-wider">Net Worth Breakdown</CardTitle>
          </CardHeader>
          <CardContent>
            {netWorthData.length > 0 ? (
              <>
                <div className="h-52">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie data={netWorthData} cx="50%" cy="50%" innerRadius={55} outerRadius={80} paddingAngle={4} dataKey="value" stroke="none">
                        {netWorthData.map((_, i) => (
                          <Cell key={i} fill={['#10b981', '#ef4444'][i]} />
                        ))}
                      </Pie>
                      <Tooltip formatter={(v) => fmt(Number(v))} contentStyle={tooltipStyle} itemStyle={{ color: 'hsl(210 40% 98%)' }} />
                    </PieChart>
                  </ResponsiveContainer>
                </div>
                <div className="flex justify-center gap-6 text-sm mt-1">
                  <div className="flex items-center gap-2"><div className="w-3 h-3 rounded-full bg-emerald-500" /><span>Assets</span></div>
                  <div className="flex items-center gap-2"><div className="w-3 h-3 rounded-full bg-red-500" /><span>Liabilities</span></div>
                </div>
              </>
            ) : (
              <div className="h-40 flex items-center justify-center text-muted-foreground text-sm">No data yet</div>
            )}
          </CardContent>
        </Card>

        {/* Income vs Expense (last 6 months) */}
        <Card className="glass-card">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-semibold text-muted-foreground uppercase tracking-wider">Income vs Expense (6 months)</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-52">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={incomeExpenseData} margin={{ top: 4, right: 4, left: -20, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" />
                  <XAxis dataKey="month" tick={{ fill: 'hsl(215 20% 65%)', fontSize: 11 }} axisLine={false} tickLine={false} />
                  <YAxis tick={{ fill: 'hsl(215 20% 65%)', fontSize: 10 }} axisLine={false} tickLine={false} tickFormatter={v => v >= 1000 ? `${(v/1000).toFixed(0)}k` : String(v)} />
                  <Tooltip formatter={(v) => fmt(Number(v))} contentStyle={tooltipStyle} itemStyle={{ color: 'hsl(210 40% 98%)' }} />
                  <Legend wrapperStyle={{ fontSize: '12px', color: 'hsl(215 20% 65%)' }} />
                  <Bar dataKey="Income" fill="#10b981" radius={[4, 4, 0, 0]} />
                  <Bar dataKey="Expense" fill="#ef4444" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        {/* Asset Allocation */}
        {assetAllocationData.length > 0 && (
          <Card className="glass-card">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-semibold text-muted-foreground uppercase tracking-wider">Asset Allocation</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-52">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie data={assetAllocationData} cx="50%" cy="50%" innerRadius={50} outerRadius={75} paddingAngle={3} dataKey="value" stroke="none">
                      {assetAllocationData.map((_, i) => (
                        <Cell key={i} fill={COLORS[i % COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip formatter={(v) => fmt(Number(v))} contentStyle={tooltipStyle} itemStyle={{ color: 'hsl(210 40% 98%)' }} />
                  </PieChart>
                </ResponsiveContainer>
              </div>
              <div className="flex flex-wrap justify-center gap-3 text-xs mt-1">
                {assetAllocationData.map((d, i) => (
                  <div key={d.name} className="flex items-center gap-1.5">
                    <div className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: COLORS[i % COLORS.length] }} />
                    <span className="text-muted-foreground">{d.name}</span>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}

        {/* Expense by Category */}
        {expenseCatData.length > 0 && (
          <Card className="glass-card">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-semibold text-muted-foreground uppercase tracking-wider">Expense by Category</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {expenseCatData.map((d, i) => {
                  const total = expenseCatData.reduce((s, x) => s + x.value, 0);
                  const pct = total > 0 ? (d.value / total) * 100 : 0;
                  return (
                    <div key={d.name}>
                      <div className="flex justify-between text-xs mb-1">
                        <span className="font-medium">{d.name}</span>
                        <span className="text-muted-foreground">{fmt(d.value)} ({pct.toFixed(1)}%)</span>
                      </div>
                      <div className="h-1.5 bg-secondary rounded-full overflow-hidden">
                        <div
                          className="h-full rounded-full transition-all"
                          style={{ width: `${pct}%`, backgroundColor: COLORS[i % COLORS.length] }}
                        />
                      </div>
                    </div>
                  );
                })}
              </div>
            </CardContent>
          </Card>
        )}
      </div>

      <BottomNav />
    </div>
  );
}
