import { useState } from "react";
import { useDashboard } from "@/hooks/use-dashboard";
import { BottomNav } from "@/components/BottomNav";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Loader2, TrendingUp, Wallet, ShieldAlert, ArrowUpRight, ArrowDownRight, BarChart2 } from "lucide-react";
import { motion } from "framer-motion";
import { CreateTransactionDialog } from "@/components/CreateTransactionDialog";
import { Link } from "wouter";

export default function Dashboard() {
  const { data, isLoading, error } = useDashboard();
  const [txType, setTxType] = useState<"INCOME" | "EXPENSE" | null>(null);
  const [txOpen, setTxOpen] = useState(false);

  if (isLoading) {
    return (
      <div className="flex h-screen items-center justify-center bg-background">
        <Loader2 className="w-10 h-10 animate-spin text-primary" />
      </div>
    );
  }

  if (error || !data) {
    return (
      <div className="flex h-screen items-center justify-center bg-background text-destructive">
        Error loading dashboard.
      </div>
    );
  }

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: data.currency,
      maximumFractionDigits: 0
    }).format(amount);
  };

  const container = {
    hidden: { opacity: 0 },
    show: { opacity: 1, transition: { staggerChildren: 0.08 } }
  };

  const item = {
    hidden: { y: 20, opacity: 0 },
    show: { y: 0, opacity: 1 }
  };

  const savings = data.monthlyIncome - data.monthlyExpenses;

  return (
    <div className="min-h-screen bg-background pb-24 font-sans text-foreground">
      {/* Header */}
      <header className="px-6 pt-10 pb-6 bg-gradient-to-b from-primary/10 to-transparent">
        <div className="flex items-center justify-between mb-4">
          <div>
            <p className="text-sm text-muted-foreground font-medium">Total Net Worth</p>
            <div className="mt-1 text-4xl font-bold tracking-tight text-white font-display" data-testid="text-net-worth">
              {formatCurrency(data.netWorth)}
            </div>
          </div>
          <Link href="/settings">
            <div className="h-11 w-11 rounded-full bg-primary/20 flex items-center justify-center cursor-pointer hover:bg-primary/30 transition-colors border border-primary/20">
              <span className="font-bold text-primary text-sm">NW</span>
            </div>
          </Link>
        </div>
      </header>

      <motion.main
        variants={container}
        initial="hidden"
        animate="show"
        className="px-4 space-y-5"
      >
        {/* Assets vs Liabilities */}
        <div className="grid grid-cols-2 gap-3">
          <motion.div variants={item}>
            <Card className="bg-card border border-green-500/10 shadow-lg shadow-black/20">
              <CardContent className="p-4">
                <div className="flex items-center gap-2 mb-2">
                  <div className="p-1.5 rounded-lg bg-green-500/10">
                    <Wallet className="w-3.5 h-3.5 text-green-500" />
                  </div>
                  <span className="text-xs font-medium text-muted-foreground">Assets</span>
                </div>
                <div className="text-xl font-bold text-green-400" data-testid="text-total-assets">
                  {formatCurrency(data.totalAssets)}
                </div>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div variants={item}>
            <Card className="bg-card border border-red-500/10 shadow-lg shadow-black/20">
              <CardContent className="p-4">
                <div className="flex items-center gap-2 mb-2">
                  <div className="p-1.5 rounded-lg bg-red-500/10">
                    <ShieldAlert className="w-3.5 h-3.5 text-red-500" />
                  </div>
                  <span className="text-xs font-medium text-muted-foreground">Liabilities</span>
                </div>
                <div className="text-xl font-bold text-red-400" data-testid="text-total-liabilities">
                  {formatCurrency(data.totalLiabilities)}
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </div>

        {/* Monthly Summary */}
        <motion.div variants={item}>
          <h3 className="text-xs uppercase font-semibold text-muted-foreground mb-2 px-1">This Month</h3>
          <div className="grid grid-cols-3 gap-2">
            <Card className="bg-card border-white/5">
              <CardContent className="p-3 text-center">
                <ArrowUpRight className="w-4 h-4 text-green-400 mx-auto mb-1" />
                <p className="text-[10px] text-muted-foreground">Income</p>
                <p className="text-sm font-bold text-green-400" data-testid="text-monthly-income">
                  {formatCurrency(data.monthlyIncome)}
                </p>
              </CardContent>
            </Card>
            <Card className="bg-card border-white/5">
              <CardContent className="p-3 text-center">
                <ArrowDownRight className="w-4 h-4 text-red-400 mx-auto mb-1" />
                <p className="text-[10px] text-muted-foreground">Expenses</p>
                <p className="text-sm font-bold text-red-400" data-testid="text-monthly-expenses">
                  {formatCurrency(data.monthlyExpenses)}
                </p>
              </CardContent>
            </Card>
            <Card className={`border-white/5 ${savings >= 0 ? 'bg-green-500/5' : 'bg-red-500/5'}`}>
              <CardContent className="p-3 text-center">
                <TrendingUp className={`w-4 h-4 mx-auto mb-1 ${savings >= 0 ? 'text-green-400' : 'text-red-400'}`} />
                <p className="text-[10px] text-muted-foreground">Savings</p>
                <p className={`text-sm font-bold ${savings >= 0 ? 'text-green-400' : 'text-red-400'}`} data-testid="text-monthly-savings">
                  {formatCurrency(savings)}
                </p>
              </CardContent>
            </Card>
          </div>
        </motion.div>

        {/* Gold Card */}
        {data.goldMetrics && (
          <motion.div variants={item}>
            <div className="relative overflow-hidden rounded-2xl bg-gradient-to-br from-yellow-500/20 to-orange-500/10 border border-yellow-500/20 p-5">
              <div className="flex justify-between items-start mb-3">
                <div>
                  <h3 className="text-yellow-400 font-bold flex items-center gap-2 text-sm">
                    <TrendingUp className="w-4 h-4" /> Gold Portfolio
                  </h3>
                  <p className="text-xs text-yellow-500/60 mt-0.5">
                    {data.goldMetrics.totalWeight}g Holdings
                  </p>
                </div>
                <div className={`text-xs font-semibold px-2.5 py-1 rounded-full ${data.goldMetrics.plPercent >= 0 ? 'bg-green-500/20 text-green-400' : 'bg-red-500/20 text-red-400'}`}>
                  {data.goldMetrics.plPercent >= 0 ? '+' : ''}{data.goldMetrics.plPercent.toFixed(2)}%
                </div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <span className="text-[10px] text-muted-foreground uppercase tracking-wider">Current Value</span>
                  <div className="text-base font-bold text-foreground">
                    {formatCurrency(data.goldMetrics.currentValue)}
                  </div>
                </div>
                <div>
                  <span className="text-[10px] text-muted-foreground uppercase tracking-wider">Invested</span>
                  <div className="text-base font-medium text-muted-foreground">
                    {formatCurrency(data.goldMetrics.investmentValue)}
                  </div>
                </div>
              </div>
            </div>
          </motion.div>
        )}

        {/* Quick Actions */}
        <motion.div variants={item} className="space-y-3">
          <h3 className="text-xs uppercase font-semibold text-muted-foreground px-1">Quick Actions</h3>
          <div className="grid grid-cols-2 gap-3">
            <button
              data-testid="button-add-income"
              className="p-4 rounded-xl bg-green-500/10 hover:bg-green-500/20 transition-colors border border-green-500/20 flex flex-col items-center gap-2"
              onClick={() => { setTxType("INCOME"); setTxOpen(true); }}
            >
              <ArrowUpRight className="w-6 h-6 text-green-400" />
              <span className="text-sm font-medium text-green-300">Add Income</span>
            </button>
            <button
              data-testid="button-add-expense"
              className="p-4 rounded-xl bg-red-500/10 hover:bg-red-500/20 transition-colors border border-red-500/20 flex flex-col items-center gap-2"
              onClick={() => { setTxType("EXPENSE"); setTxOpen(true); }}
            >
              <ArrowDownRight className="w-6 h-6 text-red-400" />
              <span className="text-sm font-medium text-red-300">Add Expense</span>
            </button>
          </div>

          <Link href="/reports">
            <button className="w-full p-3.5 rounded-xl bg-secondary/40 hover:bg-secondary/60 transition-colors border border-white/5 flex items-center justify-center gap-2">
              <BarChart2 className="w-4 h-4 text-primary" />
              <span className="text-sm font-medium text-muted-foreground">View Reports & Charts</span>
            </button>
          </Link>
        </motion.div>
      </motion.main>

      <CreateTransactionDialog
        open={txOpen}
        onOpenChange={setTxOpen}
        defaultType={txType ?? "EXPENSE"}
      />

      <BottomNav />
    </div>
  );
}
