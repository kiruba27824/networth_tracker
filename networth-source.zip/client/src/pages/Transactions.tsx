import { useState } from "react";
import { useTransactions, useDeleteTransaction } from "@/hooks/use-transactions";
import { BottomNav } from "@/components/BottomNav";
import { PageHeader } from "@/components/PageHeader";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { CreateTransactionDialog } from "@/components/CreateTransactionDialog";
import { Trash2, ArrowUpRight, ArrowDownRight, Plus, Search } from "lucide-react";
import { Input } from "@/components/ui/input";
import { motion, AnimatePresence } from "framer-motion";
import { format } from "date-fns";

export default function Transactions() {
  const { data: transactions, isLoading } = useTransactions();
  const { mutate: deleteTransaction } = useDeleteTransaction();
  const [open, setOpen] = useState(false);
  const [defaultType, setDefaultType] = useState<"INCOME" | "EXPENSE">("EXPENSE");
  const [filter, setFilter] = useState<"ALL" | "INCOME" | "EXPENSE">("ALL");
  const [search, setSearch] = useState("");

  const filtered = (transactions ?? []).filter(t => {
    const matchesFilter = filter === "ALL" || t.type === filter;
    const matchesSearch = !search || 
      t.category.toLowerCase().includes(search.toLowerCase()) ||
      (t.description ?? "").toLowerCase().includes(search.toLowerCase());
    return matchesFilter && matchesSearch;
  }).sort((a, b) => new Date(b.date!).getTime() - new Date(a.date!).getTime());

  const totalIncome = filtered.filter(t => t.type === "INCOME").reduce((sum, t) => sum + Number(t.amount), 0);
  const totalExpense = filtered.filter(t => t.type === "EXPENSE").reduce((sum, t) => sum + Number(t.amount), 0);

  const formatAmount = (amount: number | string) =>
    new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR', maximumFractionDigits: 0 }).format(Number(amount));

  return (
    <div className="min-h-screen bg-background pb-24 px-4 pt-8">
      <PageHeader
        title="Transactions"
        subtitle="Income & expenses"
        action={
          <Button
            className="rounded-full w-12 h-12 shadow-lg shadow-primary/25"
            onClick={() => { setDefaultType("EXPENSE"); setOpen(true); }}
            data-testid="button-add-transaction"
          >
            <Plus className="w-5 h-5" />
          </Button>
        }
      />

      {/* Filter Bar */}
      <div className="flex gap-2 mb-4">
        {(["ALL", "INCOME", "EXPENSE"] as const).map(f => (
          <button
            key={f}
            data-testid={`filter-${f.toLowerCase()}`}
            onClick={() => setFilter(f)}
            className={`px-3 py-1.5 rounded-full text-xs font-semibold transition-all ${
              filter === f
                ? f === "INCOME" ? "bg-green-500/20 text-green-400 border border-green-500/30"
                  : f === "EXPENSE" ? "bg-red-500/20 text-red-400 border border-red-500/30"
                  : "bg-primary/20 text-primary border border-primary/30"
                : "bg-secondary/40 text-muted-foreground border border-white/5"
            }`}
          >
            {f}
          </button>
        ))}
      </div>

      {/* Search */}
      <div className="relative mb-4">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
        <Input
          placeholder="Search transactions..."
          value={search}
          onChange={e => setSearch(e.target.value)}
          className="pl-9 bg-background/50 border-white/10"
          data-testid="input-search-transactions"
        />
      </div>

      {/* Summary row */}
      {filtered.length > 0 && (
        <div className="grid grid-cols-2 gap-2 mb-4">
          <div className="bg-green-500/10 border border-green-500/20 rounded-xl p-3 text-center">
            <p className="text-[10px] text-muted-foreground uppercase">Income</p>
            <p className="text-sm font-bold text-green-400">{formatAmount(totalIncome)}</p>
          </div>
          <div className="bg-red-500/10 border border-red-500/20 rounded-xl p-3 text-center">
            <p className="text-[10px] text-muted-foreground uppercase">Expenses</p>
            <p className="text-sm font-bold text-red-400">{formatAmount(totalExpense)}</p>
          </div>
        </div>
      )}

      {/* Quick add buttons */}
      <div className="flex gap-2 mb-4">
        <button
          data-testid="button-add-income"
          onClick={() => { setDefaultType("INCOME"); setOpen(true); }}
          className="flex-1 flex items-center justify-center gap-2 py-2.5 rounded-xl bg-green-500/10 border border-green-500/20 text-green-400 text-sm font-medium hover:bg-green-500/20 transition-colors"
        >
          <ArrowUpRight className="w-4 h-4" /> Add Income
        </button>
        <button
          data-testid="button-add-expense"
          onClick={() => { setDefaultType("EXPENSE"); setOpen(true); }}
          className="flex-1 flex items-center justify-center gap-2 py-2.5 rounded-xl bg-red-500/10 border border-red-500/20 text-red-400 text-sm font-medium hover:bg-red-500/20 transition-colors"
        >
          <ArrowDownRight className="w-4 h-4" /> Add Expense
        </button>
      </div>

      {/* Transaction List */}
      {isLoading ? (
        <div className="space-y-3">
          {[1,2,3,4].map(i => <div key={i} className="h-16 bg-secondary/30 rounded-2xl animate-pulse" />)}
        </div>
      ) : (
        <div className="space-y-3">
          <AnimatePresence>
            {filtered.map((tx) => (
              <motion.div
                key={tx.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.95 }}
                layout
              >
                <Card className="glass-card hover:bg-card/50 transition-colors group" data-testid={`card-transaction-${tx.id}`}>
                  <div className="p-4 flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className={`w-9 h-9 rounded-full flex items-center justify-center ${
                        tx.type === 'INCOME' ? 'bg-green-500/10' : 'bg-red-500/10'
                      }`}>
                        {tx.type === 'INCOME'
                          ? <ArrowUpRight className="w-4 h-4 text-green-400" />
                          : <ArrowDownRight className="w-4 h-4 text-red-400" />
                        }
                      </div>
                      <div>
                        <p className="font-semibold text-sm">{tx.category}</p>
                        <p className="text-xs text-muted-foreground">
                          {tx.description || ""}{tx.description && tx.date ? " · " : ""}
                          {tx.date ? format(new Date(tx.date), "MMM d, yyyy") : ""}
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className={`text-base font-bold ${tx.type === 'INCOME' ? 'text-green-400' : 'text-red-400'}`}>
                        {tx.type === 'INCOME' ? '+' : '-'}{formatAmount(tx.amount)}
                      </div>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-7 w-7 text-destructive hover:text-destructive hover:bg-destructive/10 opacity-0 group-hover:opacity-100 transition-opacity"
                        onClick={() => { if(confirm("Delete this transaction?")) deleteTransaction(tx.id); }}
                        data-testid={`button-delete-transaction-${tx.id}`}
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </Button>
                    </div>
                  </div>
                </Card>
              </motion.div>
            ))}
          </AnimatePresence>

          {filtered.length === 0 && (
            <div className="text-center py-12 text-muted-foreground">
              <ArrowUpRight className="w-12 h-12 mx-auto mb-4 opacity-20" />
              <p className="text-sm">No transactions yet.</p>
              <p className="text-xs mt-1">Add your first income or expense above.</p>
            </div>
          )}
        </div>
      )}

      <CreateTransactionDialog
        open={open}
        onOpenChange={setOpen}
        defaultType={defaultType}
      />

      <BottomNav />
    </div>
  );
}
