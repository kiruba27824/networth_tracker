import { useState } from "react";
import { BottomNav } from "@/components/BottomNav";
import { PageHeader } from "@/components/PageHeader";
import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { LogOut, Globe, ChevronRight, BarChart2, User } from "lucide-react";
import { Link } from "wouter";
import { useToast } from "@/hooks/use-toast";

export default function Settings() {
  const { user, logout } = useAuth();
  const { toast } = useToast();
  const [currency, setCurrency] = useState(user?.preferredCurrency || "INR");

  const currencies = [
    { code: "INR", symbol: "₹", label: "Indian Rupee" },
    { code: "AED", symbol: "د.إ", label: "UAE Dirham" },
    { code: "USD", symbol: "$", label: "US Dollar" },
  ];

  const handleCurrencyChange = async (code: string) => {
    setCurrency(code);
    try {
      const res = await fetch("/api/user/currency", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify({ currency: code }),
      });
      if (res.ok) {
        toast({ title: "Currency updated", description: `Now using ${code}` });
      }
    } catch {
      toast({ title: "Failed to update currency", variant: "destructive" });
    }
  };

  return (
    <div className="min-h-screen bg-background pb-24 px-4 pt-8">
      <PageHeader title="Settings" />

      <div className="space-y-5">
        {/* Profile Card */}
        <Card className="glass-card p-4 flex items-center gap-4">
          <div className="w-14 h-14 rounded-full bg-gradient-to-br from-primary/40 to-primary/10 flex items-center justify-center text-primary text-2xl font-bold border border-primary/20">
            {user?.name?.[0]?.toUpperCase()}
          </div>
          <div className="flex-1 min-w-0">
            <h3 className="font-bold text-lg truncate">{user?.name}</h3>
            <p className="text-sm text-muted-foreground truncate">{user?.username}</p>
          </div>
          <User className="w-5 h-5 text-muted-foreground" />
        </Card>

        {/* Currency Selection */}
        <div className="space-y-2">
          <h4 className="text-xs uppercase text-muted-foreground font-semibold ml-2 tracking-wider">Currency</h4>
          <div className="rounded-2xl bg-card border border-white/5 overflow-hidden divide-y divide-white/5">
            {currencies.map(c => (
              <button
                key={c.code}
                data-testid={`button-currency-${c.code.toLowerCase()}`}
                onClick={() => handleCurrencyChange(c.code)}
                className={`w-full flex items-center justify-between p-4 hover:bg-white/5 transition-colors text-left ${currency === c.code ? 'bg-primary/5' : ''}`}
              >
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-full bg-secondary flex items-center justify-center text-sm font-bold">
                    {c.symbol}
                  </div>
                  <div>
                    <p className="text-sm font-medium">{c.code}</p>
                    <p className="text-xs text-muted-foreground">{c.label}</p>
                  </div>
                </div>
                {currency === c.code && (
                  <div className="w-2 h-2 rounded-full bg-primary" />
                )}
              </button>
            ))}
          </div>
        </div>

        {/* Links */}
        <div className="space-y-2">
          <h4 className="text-xs uppercase text-muted-foreground font-semibold ml-2 tracking-wider">More</h4>
          <div className="rounded-2xl bg-card border border-white/5 overflow-hidden">
            <Link href="/reports">
              <button className="w-full flex items-center justify-between p-4 hover:bg-white/5 transition-colors text-left">
                <div className="flex items-center gap-3">
                  <BarChart2 className="w-5 h-5 text-primary" />
                  <span className="text-sm font-medium">Reports & Charts</span>
                </div>
                <ChevronRight className="w-4 h-4 text-muted-foreground" />
              </button>
            </Link>
          </div>
        </div>

        {/* Sign Out */}
        <div className="pt-2">
          <Button
            variant="destructive"
            className="w-full h-12 rounded-xl font-semibold"
            onClick={() => logout()}
            data-testid="button-sign-out"
          >
            <LogOut className="w-4 h-4 mr-2" />
            Sign Out
          </Button>
        </div>

        <p className="text-center text-xs text-muted-foreground/50 pb-2">NetWorth · Manage your wealth</p>
      </div>

      <BottomNav />
    </div>
  );
}
