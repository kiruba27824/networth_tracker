import { useLiabilities, useDeleteLiability } from "@/hooks/use-liabilities";
import { CreateLiabilityDialog } from "@/components/CreateLiabilityDialog";
import { BottomNav } from "@/components/BottomNav";
import { PageHeader } from "@/components/PageHeader";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Trash2, CreditCard, Landmark } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { Progress } from "@/components/ui/progress";

export default function Liabilities() {
  const { data: liabilities, isLoading } = useLiabilities();
  const { mutate: deleteLiability } = useDeleteLiability();

  const getIcon = (type: string) => {
    switch (type) {
      case 'CREDIT_CARD': return <CreditCard className="w-5 h-5 text-pink-400" />;
      case 'LOAN': return <Landmark className="w-5 h-5 text-orange-400" />;
      default: return <CreditCard className="w-5 h-5 text-gray-400" />;
    }
  };

  return (
    <div className="min-h-screen bg-background pb-24 px-4 pt-8">
      <PageHeader 
        title="Liabilities" 
        subtitle="Manage your debts"
        action={<CreateLiabilityDialog />}
      />

      {isLoading ? (
        <div className="space-y-4">
          {[1,2,3].map(i => <div key={i} className="h-20 bg-secondary/30 rounded-2xl animate-pulse" />)}
        </div>
      ) : (
        <div className="space-y-4">
          <AnimatePresence>
            {liabilities?.map((liability) => {
              const outstanding = Number(liability.outstandingAmount);
              const limit = liability.totalLimit ? Number(liability.totalLimit) : 0;
              const usagePercent = limit > 0 ? (outstanding / limit) * 100 : 0;

              return (
                <motion.div
                  key={liability.id}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, scale: 0.95 }}
                  layout
                >
                  <Card className="glass-card hover:bg-card/50 transition-colors group">
                    <div className="p-4">
                      <div className="flex items-center justify-between mb-3">
                        <div className="flex items-center space-x-4">
                          <div className="w-10 h-10 rounded-full bg-background flex items-center justify-center border border-white/5">
                            {getIcon(liability.type)}
                          </div>
                          <div>
                            <h3 className="font-semibold text-foreground">{liability.name}</h3>
                            <p className="text-xs text-muted-foreground">{liability.type}</p>
                          </div>
                        </div>
                         <div className="text-right">
                          <div className="font-bold text-lg text-red-400">
                            {new Intl.NumberFormat('en-IN', { style: 'currency', currency: liability.currency || 'INR', maximumFractionDigits: 0 }).format(outstanding)}
                          </div>
                           <div className="flex justify-end gap-2 mt-1 opacity-0 group-hover:opacity-100 transition-opacity">
                             <Button 
                                variant="ghost" 
                                size="icon" 
                                className="h-6 w-6 text-destructive hover:text-destructive hover:bg-destructive/10"
                                onClick={() => {
                                    if(confirm("Are you sure?")) deleteLiability(liability.id);
                                }}
                              >
                               <Trash2 className="w-3 h-3" />
                             </Button>
                          </div>
                        </div>
                      </div>
                      
                      {limit > 0 && (
                        <div className="space-y-1">
                          <div className="flex justify-between text-xs text-muted-foreground">
                            <span>Credit Usage</span>
                            <span>{Math.round(usagePercent)}%</span>
                          </div>
                          <Progress value={usagePercent} className="h-1.5 bg-secondary" indicatorClassName={usagePercent > 80 ? 'bg-red-500' : 'bg-primary'} />
                        </div>
                      )}
                    </div>
                  </Card>
                </motion.div>
              );
            })}
          </AnimatePresence>

          {liabilities?.length === 0 && (
            <div className="text-center py-12 text-muted-foreground">
              <CreditCard className="w-12 h-12 mx-auto mb-4 opacity-20" />
              <p>Debt free? Great job!</p>
            </div>
          )}
        </div>
      )}

      <BottomNav />
    </div>
  );
}
