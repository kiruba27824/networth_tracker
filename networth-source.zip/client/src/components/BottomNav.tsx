import { Link, useLocation } from "wouter";
import { Home, PieChart, Wallet, CreditCard, Settings, ArrowLeftRight } from "lucide-react";
import { cn } from "@/lib/utils";

export function BottomNav() {
  const [location] = useLocation();

  const navItems = [
    { href: "/", icon: Home, label: "Home" },
    { href: "/assets", icon: Wallet, label: "Assets" },
    { href: "/transactions", icon: ArrowLeftRight, label: "Transactions" },
    { href: "/liabilities", icon: CreditCard, label: "Debts" },
    { href: "/settings", icon: Settings, label: "Settings" },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-50 bg-background/90 backdrop-blur-xl border-t border-white/5 pb-safe-area-inset-bottom">
      <div className="flex justify-around items-center h-16 max-w-lg mx-auto px-2">
        {navItems.map(({ href, icon: Icon, label }) => {
          const isActive = location === href;
          return (
            <Link key={href} href={href}>
              <button
                data-testid={`nav-${label.toLowerCase().replace(/\s+/g, '-')}`}
                className={cn(
                  "flex flex-col items-center justify-center w-full h-full space-y-1 transition-all duration-200 px-3",
                  isActive ? "text-primary" : "text-muted-foreground hover:text-foreground"
                )}
              >
                <div className={cn(
                  "p-1.5 rounded-xl transition-all",
                  isActive ? "bg-primary/10" : "bg-transparent"
                )}>
                  <Icon className="w-5 h-5" strokeWidth={isActive ? 2.5 : 2} />
                </div>
                <span className="text-[10px] font-medium leading-none">{label}</span>
              </button>
            </Link>
          );
        })}
      </div>
    </nav>
  );
}
