import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertLiabilitySchema, type InsertLiability } from "@shared/schema";
import { useCreateLiability } from "@/hooks/use-liabilities";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Loader2, Plus } from "lucide-react";

const LIABILITY_TYPES = [
  { value: "CREDIT_CARD", label: "Credit Card" },
  { value: "HOME_LOAN", label: "Home Loan" },
  { value: "PERSONAL_LOAN", label: "Personal Loan" },
  { value: "VEHICLE_LOAN", label: "Vehicle Loan" },
  { value: "EDUCATION_LOAN", label: "Education Loan" },
  { value: "BORROWED", label: "Borrowed Money" },
  { value: "OTHER", label: "Other" },
];

export function CreateLiabilityDialog() {
  const [open, setOpen] = useState(false);
  const { mutate, isPending } = useCreateLiability();

  const form = useForm<InsertLiability>({
    resolver: zodResolver(insertLiabilitySchema),
    defaultValues: {
      name: "",
      outstandingAmount: "0",
      type: "CREDIT_CARD",
      currency: "INR",
      totalLimit: "0",
      emi: "0",
    },
  });

  const onSubmit = (data: InsertLiability) => {
    mutate(data, {
      onSuccess: () => {
        setOpen(false);
        form.reset();
      },
    });
  };

  const liabilityType = form.watch("type");
  const showLimit = liabilityType === "CREDIT_CARD";

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button
          className="rounded-full w-12 h-12 md:w-auto md:h-10 md:rounded-xl md:px-6 shadow-lg shadow-destructive/25 bg-destructive hover:bg-destructive/90 text-white"
          data-testid="button-open-add-liability"
        >
          <Plus className="w-5 h-5 md:mr-2" />
          <span className="hidden md:inline">Add Liability</span>
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-md bg-card border-white/10">
        <DialogHeader>
          <DialogTitle>Add New Liability</DialogTitle>
        </DialogHeader>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <FormField
              control={form.control}
              name="name"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Name</FormLabel>
                  <FormControl>
                    <Input
                      placeholder="e.g. HDFC Credit Card"
                      {...field}
                      className="bg-background/50 border-white/10"
                      data-testid="input-liability-name"
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="type"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Type</FormLabel>
                  <Select onValueChange={field.onChange} defaultValue={field.value}>
                    <FormControl>
                      <SelectTrigger className="bg-background/50 border-white/10" data-testid="select-liability-type">
                        <SelectValue placeholder="Select type" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {LIABILITY_TYPES.map(t => (
                        <SelectItem key={t.value} value={t.value}>{t.label}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />

            <div className="grid grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="outstandingAmount"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Outstanding</FormLabel>
                    <FormControl>
                      <Input type="number" step="0.01" {...field} className="bg-background/50 border-white/10" data-testid="input-liability-amount" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="currency"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Currency</FormLabel>
                    <Select onValueChange={field.onChange} defaultValue={field.value}>
                      <FormControl>
                        <SelectTrigger className="bg-background/50 border-white/10">
                          <SelectValue placeholder="Currency" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="INR">INR (₹)</SelectItem>
                        <SelectItem value="AED">AED (د.إ)</SelectItem>
                        <SelectItem value="USD">USD ($)</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              {showLimit && (
                <FormField
                  control={form.control}
                  name="totalLimit"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Credit Limit</FormLabel>
                      <FormControl>
                        <Input type="number" step="0.01" {...field} className="bg-background/50 border-white/10" data-testid="input-liability-limit" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              )}
              <FormField
                control={form.control}
                name="emi"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>EMI / Min Payment</FormLabel>
                    <FormControl>
                      <Input type="number" step="0.01" {...field} className="bg-background/50 border-white/10" data-testid="input-liability-emi" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <Button type="submit" variant="destructive" className="w-full" disabled={isPending} data-testid="button-submit-liability">
              {isPending ? <Loader2 className="w-4 h-4 animate-spin" /> : "Save Liability"}
            </Button>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}
