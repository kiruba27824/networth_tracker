import { useEffect } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertTransactionSchema, type InsertTransaction } from "@shared/schema";
import { useCreateTransaction } from "@/hooks/use-transactions";
import { useQueryClient } from "@tanstack/react-query";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Loader2 } from "lucide-react";
import { api } from "@shared/routes";

const INCOME_CATEGORIES = [
  "Salary", "Freelancing", "Business", "Rental Income",
  "Interest", "Dividends", "Bonus", "Gift", "Other Income"
];

const EXPENSE_CATEGORIES = [
  "Food", "Groceries", "Transport", "Fuel", "Shopping",
  "Rent", "Electricity", "Internet", "Mobile", "Insurance",
  "Medical", "Entertainment", "Education", "Travel",
  "Investment", "Charity", "EMI", "Miscellaneous"
];

interface Props {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  defaultType?: "INCOME" | "EXPENSE";
}

export function CreateTransactionDialog({ open, onOpenChange, defaultType = "EXPENSE" }: Props) {
  const { mutate, isPending } = useCreateTransaction();
  const queryClient = useQueryClient();

  const form = useForm<InsertTransaction>({
    resolver: zodResolver(insertTransactionSchema),
    defaultValues: {
      amount: "0",
      type: defaultType,
      category: "",
      description: "",
    },
  });

  const txType = form.watch("type");
  const categories = txType === "INCOME" ? INCOME_CATEGORIES : EXPENSE_CATEGORIES;

  useEffect(() => {
    if (open) {
      form.reset({ amount: "0", type: defaultType, category: "", description: "" });
    }
  }, [open, defaultType]);

  const onSubmit = (data: InsertTransaction) => {
    mutate(data, {
      onSuccess: () => {
        onOpenChange(false);
        queryClient.invalidateQueries({ queryKey: [api.dashboard.get.path] });
      },
    });
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md bg-card border-white/10">
        <DialogHeader>
          <DialogTitle>{defaultType === "INCOME" ? "Add Income" : "Add Expense"}</DialogTitle>
        </DialogHeader>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <FormField
              control={form.control}
              name="type"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Type</FormLabel>
                  <Select onValueChange={field.onChange} value={field.value}>
                    <FormControl>
                      <SelectTrigger className="bg-background/50 border-white/10" data-testid="select-tx-type">
                        <SelectValue placeholder="Select type" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      <SelectItem value="INCOME">Income</SelectItem>
                      <SelectItem value="EXPENSE">Expense</SelectItem>
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="category"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Category</FormLabel>
                  <Select onValueChange={field.onChange} value={field.value}>
                    <FormControl>
                      <SelectTrigger className="bg-background/50 border-white/10" data-testid="select-tx-category">
                        <SelectValue placeholder="Select category" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {categories.map(cat => (
                        <SelectItem key={cat} value={cat}>{cat}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="amount"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Amount</FormLabel>
                  <FormControl>
                    <Input
                      type="number"
                      step="0.01"
                      placeholder="0.00"
                      {...field}
                      className="bg-background/50 border-white/10"
                      data-testid="input-tx-amount"
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="description"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Description (optional)</FormLabel>
                  <FormControl>
                    <Input
                      placeholder="e.g. Monthly salary"
                      {...field}
                      value={field.value ?? ""}
                      className="bg-background/50 border-white/10"
                      data-testid="input-tx-description"
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <Button
              type="submit"
              className={`w-full ${txType === "INCOME" ? "bg-green-600 hover:bg-green-700" : "bg-red-600 hover:bg-red-700"}`}
              disabled={isPending}
              data-testid="button-submit-transaction"
            >
              {isPending ? <Loader2 className="w-4 h-4 animate-spin" /> : `Save ${txType === "INCOME" ? "Income" : "Expense"}`}
            </Button>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}
