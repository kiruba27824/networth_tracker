import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertAssetSchema, type InsertAsset } from "@shared/schema";
import { useCreateAsset } from "@/hooks/use-assets";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Loader2, Plus } from "lucide-react";

const ASSET_TYPES = [
  { value: "BANK", label: "Bank Account" },
  { value: "CASH", label: "Cash / Wallet" },
  { value: "GOLD", label: "Gold" },
  { value: "SILVER", label: "Silver" },
  { value: "STOCK", label: "Stocks" },
  { value: "MUTUAL_FUND", label: "Mutual Fund / SIP" },
  { value: "CRYPTO", label: "Cryptocurrency" },
  { value: "FD", label: "Fixed Deposit" },
  { value: "PROPERTY", label: "Property / Real Estate" },
  { value: "VEHICLE", label: "Vehicle" },
  { value: "BUSINESS", label: "Business Investment" },
  { value: "OTHER", label: "Other" },
];

export function CreateAssetDialog() {
  const [open, setOpen] = useState(false);
  const { mutate, isPending } = useCreateAsset();

  const form = useForm<InsertAsset>({
    resolver: zodResolver(insertAssetSchema),
    defaultValues: {
      name: "",
      value: "0",
      type: "BANK",
      currency: "INR",
      weight: "0",
      purchaseRate: "0",
    },
  });

  const onSubmit = (data: InsertAsset) => {
    mutate(data, {
      onSuccess: () => {
        setOpen(false);
        form.reset();
      },
    });
  };

  const assetType = form.watch("type");
  const isGoldSilver = assetType === "GOLD" || assetType === "SILVER";

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button
          className="rounded-full w-12 h-12 md:w-auto md:h-10 md:rounded-xl md:px-6 shadow-lg shadow-primary/25 bg-primary hover:bg-primary/90"
          data-testid="button-open-add-asset"
        >
          <Plus className="w-5 h-5 md:mr-2" />
          <span className="hidden md:inline">Add Asset</span>
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-md bg-card border-white/10">
        <DialogHeader>
          <DialogTitle>Add New Asset</DialogTitle>
        </DialogHeader>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <FormField
              control={form.control}
              name="name"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Asset Name</FormLabel>
                  <FormControl>
                    <Input
                      placeholder="e.g. HDFC Savings"
                      {...field}
                      className="bg-background/50 border-white/10"
                      data-testid="input-asset-name"
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="type"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Type</FormLabel>
                  <Select onValueChange={field.onChange} defaultValue={field.value}>
                    <FormControl>
                      <SelectTrigger className="bg-background/50 border-white/10" data-testid="select-asset-type">
                        <SelectValue placeholder="Select type" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {ASSET_TYPES.map(t => (
                        <SelectItem key={t.value} value={t.value}>{t.label}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />

            <div className="grid grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="value"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Current Value</FormLabel>
                    <FormControl>
                      <Input type="number" step="0.01" {...field} className="bg-background/50 border-white/10" data-testid="input-asset-value" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="currency"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Currency</FormLabel>
                    <Select onValueChange={field.onChange} defaultValue={field.value}>
                      <FormControl>
                        <SelectTrigger className="bg-background/50 border-white/10">
                          <SelectValue placeholder="Currency" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="INR">INR (₹)</SelectItem>
                        <SelectItem value="AED">AED (د.إ)</SelectItem>
                        <SelectItem value="USD">USD ($)</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            {isGoldSilver && (
              <div className="grid grid-cols-2 gap-4 p-4 rounded-xl bg-yellow-500/10 border border-yellow-500/20">
                <FormField
                  control={form.control}
                  name="weight"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-yellow-400">Weight (g)</FormLabel>
                      <FormControl>
                        <Input type="number" step="0.01" {...field} className="bg-background/50 border-white/10" data-testid="input-asset-weight" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="purchaseRate"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-yellow-400">Buy Rate/g</FormLabel>
                      <FormControl>
                        <Input type="number" step="0.01" {...field} className="bg-background/50 border-white/10" data-testid="input-asset-purchase-rate" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
            )}

            <Button type="submit" className="w-full" disabled={isPending} data-testid="button-submit-asset">
              {isPending ? <Loader2 className="w-4 h-4 animate-spin" /> : "Save Asset"}
            </Button>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}
